namespace CybersecurityChatbot
{
    public static class AsciiArt
    {
        public static readonly string Logo =
            "╔════════════════════════════════════╗\n" +
            "║      CYBERSECURITY ASSISTANT       ║\n" +
            "╚════════════════════════════════════╝";
    }
}
