namespace CybersecurityChatbot
{
    public class ChatBot
    {
        private readonly KeywordResponder _keywords;
        private readonly SentimentDetector _sentiment;
        private readonly MemoryStore _memory;

        private bool _awaitingName = true;
        private string _lastTopic = string.Empty;

        public ChatBot()
        {
            _keywords = new KeywordResponder();
            _sentiment = new SentimentDetector();
            _memory = new MemoryStore();
        }

        public string GetGreeting()
        {
            return "Welcome to the Cybersecurity Awareness Assistant! What is your name?";
        }

        public string ProcessInput(string input)
        {
            string lowerInput = input.ToLower().Trim();

            // STEP 1 - GET USER NAME
            if (_awaitingName)
            {
                _memory.UserName = input.Trim();
                _awaitingName = false;
                return $"Nice to meet you, {_memory.UserName}! Ask me about passwords, scams, phishing, privacy, or malware.";
            }

            // STEP 2 - FOLLOW UP REQUESTS
            if (lowerInput.Contains("tell me more") ||
                lowerInput.Contains("another tip") ||
                lowerInput.Contains("explain more"))
            {
                if (!string.IsNullOrEmpty(_lastTopic))
                {
                    return _keywords.GetResponse(_lastTopic);
                }

                return "Please tell me which topic you want more information about (passwords, phishing, scams, privacy, or malware).";
            }

            // STEP 3 - SENTIMENT DETECTION
            Sentiment detectedSentiment = _sentiment.Detect(lowerInput);
            string emotionResponse = _sentiment.GetSentimentResponse(detectedSentiment);

            // STEP 4 - REMEMBER FAVOURITE TOPIC
            if (lowerInput.Contains("interested in"))
            {
                foreach (string keyword in _keywords.GetKeywords())
                {
                    if (lowerInput.Contains(keyword))
                    {
                        _memory.FavouriteTopic = keyword;
                        return $"Great! I will remember that you are interested in {keyword}, {_memory.UserName}.";
                    }
                }
            }

            // STEP 5 - KEYWORD RECOGNITION
            foreach (string keyword in _keywords.GetKeywords())
            {
                if (lowerInput.Contains(keyword))
                {
                    _lastTopic = keyword;
                    string keywordResponse = _keywords.GetResponse(keyword);
                    string personalised = _memory.GetPersonalisedOpener();
                    return $"{emotionResponse}{personalised}{keywordResponse}";
                }
            }

            // STEP 6 - SPECIAL PHRASES
            if (lowerInput.Contains("how are you"))
            {
                return "I am functioning perfectly and ready to help you stay cyber-safe!";
            }

            if (lowerInput.Contains("purpose") || lowerInput.Contains("what are you"))
            {
                return "My purpose is to educate South Africans about cybersecurity threats and online safety.";
            }

            if (lowerInput.Contains("what can you do") || lowerInput.Contains("help"))
            {
                return "I can help you learn about: passwords, scams, phishing, privacy, and malware. Just ask!";
            }

            if (lowerInput.Contains("who are you"))
            {
                return "I am the Cybersecurity Awareness Assistant, here to help keep you safe online!";
            }

            // STEP 7 - FALLBACK
            return $"I did not fully understand that, {_memory.UserName}. " +
                   "Try asking about: passwords, phishing, scams, privacy, or malware.";
        }
    }
}
