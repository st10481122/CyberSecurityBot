using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace CybersecurityChatbot
{
    public partial class MainWindow : Window
    {
        private readonly ChatBot _chatBot;

        public MainWindow()
        {
            InitializeComponent();

            AudioPlayer.PlayGreeting();

            _chatBot = new ChatBot();

            AppendBotMessage(_chatBot.GetGreeting());
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            SendMessage();
        }

        private void InputBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                SendMessage();
            }
        }

        private void SendMessage()
        {
            string userInput = InputBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(userInput))
            {
                AppendBotMessage("Please enter a message.");
                return;
            }

            AppendUserMessage(userInput);

            string response = _chatBot.ProcessInput(userInput);

            AppendBotMessage(response);

            InputBox.Clear();

            // Use Dispatcher to ensure scroll happens after layout update
            Dispatcher.InvokeAsync(() => ChatScroller.ScrollToEnd(),
                System.Windows.Threading.DispatcherPriority.ContextIdle);
        }

        private void AppendUserMessage(string message)
        {
            AddMessage("🧑 You", message, "#89B4FA", HorizontalAlignment.Right);
        }

        private void AppendBotMessage(string message)
        {
            AddMessage("🤖 Bot", message, "#313244", HorizontalAlignment.Left);
        }

        private void AddMessage(string sender,
                                string message,
                                string backgroundColor,
                                HorizontalAlignment alignment)
        {
            var textBlock = new TextBlock
            {
                Text = $"{sender}: {message}",
                Foreground = Brushes.White,
                TextWrapping = TextWrapping.Wrap,
                FontSize = 14
            };

            var converter = new BrushConverter();
            var brush = converter.ConvertFromString(backgroundColor) as SolidColorBrush
                        ?? new SolidColorBrush(Colors.Gray);

            var border = new Border
            {
                Background = brush,
                Padding = new Thickness(10),
                Margin = new Thickness(5),
                CornerRadius = new CornerRadius(10),
                HorizontalAlignment = alignment,
                MaxWidth = 600,
                Child = textBlock
            };

            ChatStack.Children.Add(border);
        }
    }
}
