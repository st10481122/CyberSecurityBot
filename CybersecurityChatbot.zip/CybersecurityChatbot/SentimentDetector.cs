using System.Collections.Generic;

namespace CybersecurityChatbot
{
    public enum Sentiment
    {
        Neutral,
        Worried,
        Curious,
        Frustrated,
        Happy
    }

    public class SentimentDetector
    {
        private readonly Dictionary<Sentiment, List<string>> _sentiments;

        public SentimentDetector()
        {
            _sentiments = new Dictionary<Sentiment, List<string>>
            {
                {
                    Sentiment.Worried,
                    new List<string> { "worried", "scared", "afraid", "anxious", "nervous", "unsafe" }
                },
                {
                    Sentiment.Curious,
                    new List<string> { "curious", "wondering", "interested", "how does", "what is", "explain" }
                },
                {
                    Sentiment.Frustrated,
                    new List<string> { "frustrated", "annoyed", "confused", "don't understand", "complicated", "difficult" }
                },
                {
                    Sentiment.Happy,
                    new List<string> { "great", "awesome", "helpful", "thanks", "thank you", "amazing", "perfect" }
                }
            };
        }

        public Sentiment Detect(string input)
        {
            foreach (var entry in _sentiments)
            {
                foreach (string word in entry.Value)
                {
                    if (input.Contains(word))
                    {
                        return entry.Key;
                    }
                }
            }

            return Sentiment.Neutral;
        }

        public string GetSentimentResponse(Sentiment sentiment)
        {
            return sentiment switch
            {
                Sentiment.Worried    => "It is completely understandable to feel worried about this. ",
                Sentiment.Curious    => "That is a great topic to learn about! ",
                Sentiment.Frustrated => "I understand your frustration. Let me help clarify. ",
                Sentiment.Happy      => "I am glad this is helpful to you! ",
                _                    => string.Empty
            };
        }
    }
}
