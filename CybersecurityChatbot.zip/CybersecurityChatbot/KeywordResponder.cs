using System;
using System.Collections.Generic;

namespace CybersecurityChatbot
{
    public class KeywordResponder
    {
        private readonly Dictionary<string, List<string>> _responses;
        private readonly Random _random;

        public KeywordResponder()
        {
            _random = new Random();

            _responses = new Dictionary<string, List<string>>
            {
                {
                    "password",
                    new List<string>
                    {
                        "Use strong passwords with a mix of uppercase, lowercase, symbols, and numbers.",
                        "Never use birthdays, names, or common words as passwords.",
                        "Use a different password for every account to prevent multiple breaches.",
                        "Consider using a trusted password manager to generate and store strong passwords.",
                        "Enable two-factor authentication (2FA) wherever possible for extra security."
                    }
                },
                {
                    "phishing",
                    new List<string>
                    {
                        "Never click suspicious links in emails or SMS messages.",
                        "Check the sender email address carefully — scammers use lookalike domains.",
                        "Banks and institutions will never ask for your password via email.",
                        "When in doubt, go directly to the official website instead of clicking links.",
                        "Look for HTTPS and a padlock icon before entering any personal information online."
                    }
                },
                {
                    "privacy",
                    new List<string>
                    {
                        "Review your social media privacy settings regularly.",
                        "Avoid oversharing personal information such as your address or ID number online.",
                        "Enable two-factor authentication on all important accounts.",
                        "Be cautious about which apps you grant permissions to on your phone.",
                        "Use a VPN when connecting to public Wi-Fi networks."
                    }
                },
                {
                    "scam",
                    new List<string>
                    {
                        "Scammers often create fake urgency — slow down and verify before acting.",
                        "Never share banking OTPs with anyone, including people claiming to be from your bank.",
                        "If an offer sounds too good to be true, it almost certainly is.",
                        "Verify unexpected prize or lottery winnings by contacting the company directly.",
                        "Report scams to the South African Police Service (SAPS) and your bank immediately."
                    }
                },
                {
                    "malware",
                    new List<string>
                    {
                        "Install reputable antivirus software and keep it updated.",
                        "Never download files or programs from unknown or untrusted websites.",
                        "Keep your operating system and software updated to patch security vulnerabilities.",
                        "Avoid clicking on pop-up ads, especially ones claiming your device is infected.",
                        "Back up your important files regularly to protect against ransomware attacks."
                    }
                }
            };
        }

        public string GetResponse(string keyword)
        {
            if (_responses.TryGetValue(keyword, out List<string>? options) && options.Count > 0)
            {
                int index = _random.Next(options.Count);
                return options[index];
            }

            return "I don't have specific information on that topic yet.";
        }

        public List<string> GetKeywords()
        {
            return new List<string>(_responses.Keys);
        }
    }
}
