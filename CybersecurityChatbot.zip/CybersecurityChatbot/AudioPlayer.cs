using System;
using System.IO;
using System.Media;
using System.Reflection;

namespace CybersecurityChatbot
{
    public static class AudioPlayer
    {
        public static void PlayGreeting()
        {
            try
            {
                // Try loading from the Assets folder next to the executable first
                string exeDir = AppDomain.CurrentDomain.BaseDirectory;
                string wavPath = Path.Combine(exeDir, "Assets", "greeting.wav");

                if (File.Exists(wavPath))
                {
                    SoundPlayer player = new SoundPlayer(wavPath);
                    player.Play();
                    return;
                }

                // Try loading as an embedded/resource stream
                Assembly assembly = Assembly.GetExecutingAssembly();
                string resourceName = "CybersecurityChatbot.Assets.greeting.wav";

                using Stream? stream = assembly.GetManifestResourceStream(resourceName);
                if (stream != null)
                {
                    SoundPlayer resourcePlayer = new SoundPlayer(stream);
                    resourcePlayer.Play();
                }
            }
            catch (Exception)
            {
                // Audio is optional — silently ignore any errors
            }
        }
    }
}
