namespace CybersecurityChatbot
{
    public class MemoryStore
    {
        public string UserName { get; set; } = string.Empty;

        public string FavouriteTopic { get; set; } = string.Empty;

        public string GetPersonalisedOpener()
        {
            if (!string.IsNullOrWhiteSpace(FavouriteTopic))
            {
                return $"As someone interested in {FavouriteTopic}, ";
            }

            return string.Empty;
        }
    }
}
