# Cybersecurity Awareness Assistant

A WPF desktop chatbot that educates South Africans about cybersecurity threats and online safety.

## Features

- **WPF GUI** — Dark-themed chat interface with styled message bubbles
- **Voice greeting** — Plays a WAV greeting on startup (optional)
- **ASCII art** — Decorative header in the window
- **Keyword recognition** — Responds to: `password`, `phishing`, `privacy`, `scam`, `malware`
- **Random responses** — Multiple tips per topic, selected randomly each time
- **Sentiment detection** — Detects worried, curious, frustrated, or happy tone
- **User memory** — Remembers your name and favourite topic
- **Conversation flow** — Handles follow-up requests like "tell me more" or "another tip"
- **GitHub Actions** — Automated build on every push/PR

## Requirements

- Visual Studio 2022 or later
- .NET 8.0 SDK (Windows)
- Windows OS (WPF is Windows-only)

## How To Run

1. Clone the repository
2. Open `CybersecurityChatbot.sln` (or the `.csproj`) in Visual Studio 2022
3. *(Optional)* Place a `greeting.wav` file inside the `Assets/` folder
4. Press **F5** or click **Run** to start the application

## Project Structure

```
CybersecurityChatbot/
│
├── App.xaml                  # Application entry point
├── App.xaml.cs
├── MainWindow.xaml           # Main UI layout
├── MainWindow.xaml.cs        # UI logic
├── ChatBot.cs                # Core conversation controller
├── KeywordResponder.cs       # Keyword-to-response mapping
├── SentimentDetector.cs      # Emotion/sentiment detection
├── MemoryStore.cs            # Stores user name and topic preference
├── AudioPlayer.cs            # Plays greeting WAV on startup
├── AsciiArt.cs               # ASCII logo string
├── Assets/
│   └── greeting.wav          # (Optional) Greeting audio file
└── .github/
    └── workflows/
        └── build.yml         # GitHub Actions CI
```

## Example Topics To Ask About

| Topic      | Example Question                          |
|------------|-------------------------------------------|
| Passwords  | "How do I create a strong password?"      |
| Phishing   | "What is phishing?"                       |
| Privacy    | "How can I protect my privacy online?"    |
| Scams      | "How do I avoid scams?"                   |
| Malware    | "What is malware and how do I prevent it?"|

## GitHub Tags

- `v2.0` — Initial WPF release
- `v2.1` — Sentiment detection and memory added
